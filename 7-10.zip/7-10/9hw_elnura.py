#1A - easy
# n = int(input())
# a = []
# for i in range(n):
#     q = input()
#     a.append(q)
# print(a)

#1A - easy
# n = int(input())
# a = input().split()
# print(a)

#1B - easy
# n = int(input())
# a = list(map(int, input().split()))
# for i in a:
#     if i % 2 != 0:
#         print(i, end=' ')

#2A - medium
# n = int(input())
# a = list(map(int, input().split()))
# print(max(a), a.index(max(a)))

#2B
# n = int(input())
# a = list(map(int, input().split()))
# q = int(input())
#
# w = 0 #1 variant
# for i in a:
#     if i == q:
#         w += 1
# print(w)
# print(a.count(q)) #2 variant

#3A
# n = int(input())
# a = list(map(int, input().split()))
# mx = max(a)
# mn = min(a)
#
# mx_index = a.index(mx)
# mn_index = a.index(mn)
#
# a[mn_index] = mx
# a[mx_index] = mn
#
# print(*a)

#3B
a = list(map(int, input().split()))
c = 0
for i1 in range(len(a)):
    for i2 in range(i1 + 1, len(a)):
        if a[i1] == a[i2]:
            c += 1
print(c)

