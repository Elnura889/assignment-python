#1A - Easy
a = int(input())
b = int(input())
if a < b:
    for num in range(a, b+1):
        print(num, end=" ")
else:
    for num in range(a, b-1, -1):
        print(num, end=' ')

#1B - easy
a = int(input())
b = int(input())
for num in range(a, b-1, -1):
    if num % 2 != 0:
        print(num, end=" ")

#1B - easy
a = int(input())
b = int(input())
for num in range(a - (a + 1) % 2, b - b % 2, -2):
    print(num, end=" ")

#2A - meduim
a = int(input())
b = int(input())
c = int(input())
d = int(input())
flag = False
for num in range(a, b+1):
    if num % d == c:
        flag = True
        print(num, end=" ")
if not flag:
        print("Таких чисел нет")

#2B - medium
a = int(input())
sum = 0
for num in range(a):
    numbers = int(input())
    sum += numbers
print(sum)

#3A - hard
s = int(input())
p = int(input())
flag = False
for num in range(1, s+1):
    if p % num == 0 and p // num + num == s:
        print(p//num, num)

#3B - hard
a = int(input())
b = int(input())
c = int(input())
d = int(input())
for x in range(-100, 101):
    if a * x**3 + b * x**2 + c * x + d == 0:
        print(x, end=" ")

