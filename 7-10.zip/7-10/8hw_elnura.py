#1A - easy
a = int(input())
b = int(input())
for i in range(a, b+1):
    # print(i ** 0.5, i ** 0.5 % 1) #проверка
    if i ** 0.5 % 1 > 0:
        continue
    print(i, end=" ")

#1B - easy
n = int(input())
for i in range(1, n+1):
    if n % i == 0:
        print(i, end=' ')

#2A - medium
n = int(input())
flag = False
for i in range(n):
    num = int(input())
    if num == 0:
        flag = True
if flag:
    print("YES")
else:
    print("NO")

#2B - medium
n = int(input())
zero = 0
poz = 0
neg = 0
for i in range(n):
    num = int(input())
    if num > 0:
        poz += 1
    elif num < 0:
        neg += 1
    else:
        zero += 1
print(zero, poz, neg)

#3A - hard
n = int(input())
ans = '' #сохраняем предыдущий ответ
for num in range(1, n+1):
    ans += str(num) #работаем со строками
    print(ans)

#3B - hard
n = int(input())
sum = ((n+1)*n)//2 #формула для вычисления суммы
for i in range(n-1):
    num = int(input())
    sum -= num
print(sum)






