#1A
n = input()
print(n.count(" ") + 1) #считает пробелы и добавляет 1, чтобы считать колво слов

#1B (my)
b = input()
k = input()
print(b.replace(k[0], k[2]))

#1B (decode)
n = input()
a, b = input().split()
print(n.replace(a, b))

#2A
n = input()
middle = (len(n) + 1) // 2
first = n[:middle]
second = n[middle:]
print(second + first)

#2B
n = input()
for i in n:
    print(ord(i), end=" ") #ASCII кодировка

#3A (my)
n = input()
for i in n:
    if i.isupper():
        l = (ord(i) - 12) % 26
    else:
        l = (ord(i) - 96) % 26
    print(i, l, sep=":", end=" ")

#3A (decode)
n = input().lower()
for i in n:
    print(i, ord(i) - 96, sep=":", end=" " )

#3B
n = input().split()

for i in n:
    print(len(i), end=' ')




