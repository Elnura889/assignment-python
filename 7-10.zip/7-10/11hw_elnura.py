#1A
n = set(map(int, input().split()))
a = set()
for i in n:
    if i % 3 != 0:
        a.add(i)
print(a)

#1B - nep
n = set(map(int, input().split()))
a = set()
for i in n:
    ans = i
    while i > 1:
        if i % 2 == 0:
            i //= 2
        else:
            break
    if i == 1:
        a.add(ans)
print(a)

#2A
a = set(map(int, input().split()))
m = max(a)
n = min(a)
print(f"max - {m}")
print(f"min - {n}")

#2B
a = set(map(int, input().split()))
b = len(a)
print(b)

#3A
n = list(map(int, input().split()))
a = set()

for i in n:
    if i in a:
        print("YES")
    else:
        print("NO")
        a.add(i)

#3B
n = int(input())
a = set()
for i in range(n):
    k = input().split()
    a.update(k)
print(len(a))


